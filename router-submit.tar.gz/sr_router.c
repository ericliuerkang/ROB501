/**********************************************************************
 * file:  sr_router.c
 * date:  Mon Feb 18 12:50:42 PST 2002
 * Contact: casado@stanford.edu
 *
 * Description:
 *
 * This file contains all the functions that interact directly
 * with the routing table, as well as the main entry method
 * for routing.
 *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>


#include "sr_if.h"
#include "sr_rt.h"
#include "sr_router.h"
#include "sr_protocol.h"
#include "sr_arpcache.h"
#include "sr_utils.h"

/*---------------------------------------------------------------------
 * Method: sr_init(void)
 * Scope:  Global
 *
 * Initialize the routing subsystem
 *
 *---------------------------------------------------------------------*/

void sr_init(struct sr_instance* sr)
{
    /* REQUIRES */
    assert(sr);

    /* Initialize cache and cache cleanup thread */
    sr_arpcache_init(&(sr->cache));

    pthread_attr_init(&(sr->attr));
    pthread_attr_setdetachstate(&(sr->attr), PTHREAD_CREATE_JOINABLE);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_t thread;

    pthread_create(&thread, &(sr->attr), sr_arpcache_timeout, sr);
    
    /* Add initialization code here! */

} /* -- sr_init -- */

/*---------------------------------------------------------------------
 * Method: sr_handlepacket(uint8_t* p,char* interface)
 * Scope:  Global
 *
 * This method is called each time the router receives a packet on the
 * interface.  The packet buffer, the packet length and the receiving
 * interface are passed in as parameters. The packet is complete with
 * ethernet headers.
 *
 * Note: Both the packet buffer and the character's memory are handled
 * by sr_vns_comm.c that means do NOT delete either.  Make a copy of the
 * packet instead if you intend to keep it around beyond the scope of
 * the method call.
 *
 *---------------------------------------------------------------------*/
/*custom longest prefix matching*/
struct sr_rt* find_match(struct sr_instance* sr, uint32_t ip)
{
  struct sr_rt* res = NULL;
  struct sr_rt* cur = sr->routing_table;
  /*linear search routing table*/
  while (cur) {
    in_addr_t mask = cur->mask.s_addr;
    if((cur->dest.s_addr & mask)==(ip & mask)){
      /*compare length to update res*/
      if ((!res)||(mask>res->mask.s_addr)) {
        res = cur;
      }
    }
    cur = cur->next;
  }
  if (!res){
    printf("no match\n");
  }
  return res;
}

/*custom send packet*/
void send_packet(struct sr_instance* sr /* borrowed */,
                         uint8_t* buf /* borrowed */ ,
                         unsigned int len,
                         struct sr_if* interface,
                         uint32_t ip)
{
  struct sr_arpentry* mapping = sr_arpcache_lookup(&sr->cache, ip);
  if (mapping){
    printf("mapping found\n");

    /*make ethernet hdr and copy the MAC addresses into hdr*/
    sr_ethernet_hdr_t* ether_hdr = (sr_ethernet_hdr_t*)buf;
    memcpy(ether_hdr->ether_dhost, mapping->mac, ETHER_ADDR_LEN);
    memcpy(ether_hdr->ether_shost, interface->addr, ETHER_ADDR_LEN);
    sr_send_packet(sr, buf, len, interface->name);
    free(mapping);
  }
  else{
    printf("mapping not found\n");
    struct sr_arpreq* arpreq = sr_arpcache_queuereq(&sr->cache, ip, buf, len, interface->name);
    
    handle_arpreq(sr, arpreq);
  }
}

void send_icmp_msg(struct sr_instance* sr, uint8_t* packet, unsigned int len, uint8_t type, uint8_t code){
  printf("icmp type: %u, code: %u\n", type, code);

  /*initiate ethernet hdr*/
  sr_ethernet_hdr_t* ether_hdr = (sr_ethernet_hdr_t*)packet;
  
  /*initiate ip hdr*/
  sr_ip_hdr_t* ip_hdr = (sr_ip_hdr_t*)(packet+sizeof(sr_ethernet_hdr_t));

  /*find the routing tale entry*/
  struct sr_rt* entry = find_match(sr, ip_hdr->ip_src);
  if (!entry) {
    printf("send icmp msg: routing table entry not found\n");
    return;
  }

  struct sr_if* interface = sr_get_interface(sr, entry->interface);
  
  /*echo reply, just need to configure hdrs and send*/
  if (type == 0) {
    /*configure ether hdr*/
    memset(ether_hdr->ether_dhost, 0, ETHER_ADDR_LEN);
    memset(ether_hdr->ether_shost, 0, ETHER_ADDR_LEN);

    /*configure ip hdr*/
    uint32_t tmp = ip_hdr->ip_src;
    ip_hdr->ip_src = ip_hdr->ip_dst;
    ip_hdr->ip_dst = tmp;
    /* recalculate checksum */
    ip_hdr->ip_sum = 0;
    ip_hdr->ip_sum = cksum(ip_hdr, sizeof(sr_ip_hdr_t));

    /*configure icmp hdr*/
    sr_icmp_hdr_t* icmp_hdr = (sr_icmp_hdr_t*)(packet+sizeof(sr_ethernet_hdr_t)+sizeof(sr_ip_hdr_t));
    icmp_hdr->icmp_type = type;
    icmp_hdr->icmp_code = code;
    /*compute icmp sum*/
    icmp_hdr->icmp_sum = 0;
    icmp_hdr->icmp_sum = cksum(icmp_hdr, ntohs(ip_hdr->ip_len) - (ip_hdr->ip_hl * 4));

    /*send_packet(sr, packet, len, interface, ip_hdr->ip_dst);*/
    send_packet(sr, packet, len, interface, entry->gw.s_addr);
    return;
  }

  /*error messages, need to make new packet*/
  else {
    printf("entered else\n");
    uint8_t* new_packet = malloc(sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t));
    assert(new_packet);

    /*configure ether hdr*/
    sr_ethernet_hdr_t* new_ether_hdr = (sr_ethernet_hdr_t*)new_packet;
    memset(new_ether_hdr->ether_dhost, 0, ETHER_ADDR_LEN);
    memset(new_ether_hdr->ether_shost, 0, ETHER_ADDR_LEN);
    new_ether_hdr->ether_type = htons(ethertype_ip);

    /*configure ip hdr*/
    sr_ip_hdr_t* new_ip_hdr = (sr_ip_hdr_t*)(new_packet+sizeof(sr_ethernet_hdr_t));
    if (code == 3) {
      new_ip_hdr->ip_src = ip_hdr->ip_dst;
    }
    else {
      new_ip_hdr->ip_src = interface->ip;
    }
    new_ip_hdr->ip_dst = ip_hdr->ip_src;
    new_ip_hdr->ip_hl = sizeof(sr_ip_hdr_t)/4;
    new_ip_hdr->ip_v    = 4;
    new_ip_hdr->ip_id = htons(0);
    new_ip_hdr->ip_len = htons(sizeof(sr_ip_hdr_t)+sizeof(sr_icmp_t3_hdr_t));
    new_ip_hdr->ip_off = htons(IP_DF);
    new_ip_hdr->ip_p    = ip_protocol_icmp;
    new_ip_hdr->ip_ttl  = 64;
    new_ip_hdr->ip_tos = 0;
    /*make checksum*/
    new_ip_hdr->ip_sum = 0;
    new_ip_hdr->ip_sum = cksum(new_ip_hdr, sizeof(sr_ip_hdr_t));

    /*configure icmp hdr*/
    sr_icmp_t3_hdr_t* new_icmp_hdr = (sr_icmp_t3_hdr_t*)(new_packet+sizeof(sr_ethernet_hdr_t)+(ip_hdr->ip_hl*4));
    new_icmp_hdr->icmp_type = type;
    new_icmp_hdr->icmp_code = code;
    new_icmp_hdr->unused = 0;
    new_icmp_hdr->next_mtu = 0;
    memcpy(new_icmp_hdr->data, ip_hdr, ICMP_DATA_SIZE);
    new_icmp_hdr->icmp_sum = 0;
    new_icmp_hdr->icmp_sum = cksum(new_icmp_hdr, sizeof(sr_icmp_t3_hdr_t));

    send_packet(sr, new_packet, (sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t)), interface, entry->gw.s_addr);
    free(new_packet);
  }
}

void handle_arp_packet(struct sr_instance* sr,
        uint8_t * packet/* lent */,
        unsigned int len,
        char* interface/* lent */)
{
  /*get arp header*/
  sr_arp_hdr_t* arp_hdr = (sr_arp_hdr_t*)(packet+sizeof(sr_ethernet_hdr_t));

  /*sanity checks*/
  if (ntohs(arp_hdr->ar_hrd)!=arp_hrd_ethernet){
    printf("packet is not an ethernet frame\n");
    return;
  }
  if (ntohs(arp_hdr->ar_pro)!=ethertype_ip){
    printf("packet is not an IP packet\n");
    return;
  }
  if (sr_get_interface_by_ip(sr, arp_hdr->ar_tip)==NULL){
    printf("arp destination not on this router");
    return;
  }

  /*in the case of an arp request => reply with switched addresses*/
  if (ntohs(arp_hdr->ar_op)==arp_op_request){
    printf("received arp request\n");

    /*first copy the whole arp*/
    uint8_t* reply = malloc(len);
    memcpy(reply, packet, len);

    /*record incoming interface*/
    struct sr_if* sif = sr_get_interface(sr, interface);

    /*make ethernet hdr of the reply*/
    sr_ethernet_hdr_t* ether_hdr = (sr_ethernet_hdr_t*)reply;
    /*invert MAC addresses*/
    memcpy(ether_hdr->ether_dhost, ether_hdr->ether_shost, ETHER_ADDR_LEN);
    memcpy(ether_hdr->ether_shost, sif->addr, ETHER_ADDR_LEN);

    /*make arp hdr of the reply*/
    sr_arp_hdr_t* arp_hdr = (sr_arp_hdr_t*)(reply+sizeof(sr_ethernet_hdr_t));
    /*invert MAC addresses*/
    memcpy(arp_hdr->ar_tha, arp_hdr->ar_sha, ETHER_ADDR_LEN);
    memcpy(arp_hdr->ar_sha, sif->addr, ETHER_ADDR_LEN);
    /*invert IP addresses*/
    arp_hdr->ar_tip = arp_hdr->ar_sip;
    arp_hdr->ar_sip = sif->ip;

    /*send the finished reply packet*/
    send_packet(sr, packet, len, sif, arp_hdr->ar_tip);
  }

  /*in the case of an arp reply => store information*/
  if (ntohs(arp_hdr->ar_op)==arp_op_reply){
    printf("received arp reaply\n");

    /*get the cached arp request corresponding to this reply and insert the mac ip mapping into the cache*/
    struct sr_arpreq* request = sr_arpcache_insert(&sr->cache, arp_hdr->ar_sha, arp_hdr->ar_sip);
    /*if there is a request queue deal with those packets*/
    if (request){
      /*get the packets*/
      struct sr_packet* packet = request->packets;
      /*loop through list of packets in queue to send them*/
      while (packet){
        struct sr_if* sif = sr_get_interface(sr, packet->iface);
        if (sif){
          sr_ethernet_hdr_t* ether_hdr = (sr_ethernet_hdr_t*)(packet->buf);
          /*set ethernet addresses*/
          memcpy(ether_hdr->ether_dhost, arp_hdr->ar_sha, ETHER_ADDR_LEN);
          memcpy(ether_hdr->ether_shost, sif->addr, ETHER_ADDR_LEN);
          /*send the finished packet*/
          sr_send_packet(sr, packet->buf, packet->len, packet->iface);
        }
        packet = packet->next;
      }
      sr_arpreq_destroy(&sr->cache, request);
    }
  }
}

void handle_ip_packet(struct sr_instance* sr,
        uint8_t * packet/* lent */,
        unsigned int len,
        char* interface/* lent */)
{
  printf("received ip packet\n");

  /* get the ip header*/
  sr_ip_hdr_t* ip_hdr = (sr_ip_hdr_t*)(packet+sizeof(sr_ethernet_hdr_t));
  /*verify packet size*/
  if (ip_hdr->ip_len<20){
    printf("ip length too small, with size %u \n", ip_hdr->ip_len);
    return;
  }
  /*verify checksum by making checksum zero, computing checksum and then setting it back*/
  uint16_t packet_cksum = ip_hdr->ip_sum;
  ip_hdr->ip_sum = 0;
  uint16_t computed_cksum = cksum(ip_hdr, ip_hdr->ip_hl*4);
  ip_hdr->ip_sum = packet_cksum;
  if (packet_cksum != computed_cksum){
    printf("ip cksum wrong \n");
    return;
  }
  /*if one of the interfaces on this router is the destination of the packet*/
  if (sr_get_interface_by_ip(sr, ip_hdr->ip_dst)){
    /* if the content is icmp*/
    if (ip_hdr->ip_p == ip_protocol_icmp){
      /* verify header size*/
      if(len < sizeof(sr_ethernet_hdr_t) + sizeof(sr_icmp_hdr_t) + (ip_hdr->ip_hl * 4)) {
        printf("Error: icmp header too short.\n");
        return;
      }
      /* get icmp hdr*/
      sr_icmp_hdr_t* icmp_hdr = (sr_icmp_hdr_t*)(packet+sizeof(sr_ip_hdr_t)+sizeof(sr_ethernet_hdr_t));
      uint16_t icmp_cksum = icmp_hdr->icmp_sum;
      icmp_hdr->icmp_sum = 0;
      uint16_t computed_icmp_cksum = cksum(icmp_hdr, ntohs(ip_hdr->ip_len)-(ip_hdr->ip_hl*4));
      icmp_hdr->icmp_sum = icmp_cksum;
      if (icmp_cksum != computed_icmp_cksum){
        printf("icmp cksum wrong\n");
        return;
      }

      /*echo reply (type 0 as specified in assignment document)*/
      if (icmp_hdr->icmp_type == 0){
        send_icmp_msg(sr, packet, len, 0, 0);
      }
    }
    
    if (ip_hdr->ip_p == ip_protocol_tcp || ip_hdr->ip_p == ip_protocol_udp){
      send_icmp_msg(sr, packet, len, 3, 3);
      return;
    }
  }
  /*if the destination of the packet is elsewhere => need forwarding*/
  else{
    /*decrement ttl*/
    ip_hdr->ip_ttl--;
    if (ip_hdr->ip_ttl==0){
      printf("ip packet ttl is 0, packet expired\n");
      send_icmp_msg(sr, packet, len, 11, 0);
      return;
    }

    /* recompute cksum*/
    ip_hdr->ip_sum = 0;
    ip_hdr->ip_sum = cksum(ip_hdr, ip_hdr->ip_hl*4);

    /*find interface to forward to and send it*/
    struct sr_rt* rt = find_match(sr, ip_hdr->ip_dst);
    if (!rt){
      printf("ip destination not in routing table\n");
      send_icmp_msg(sr, packet, len, 3, 0);
      return;
    }

    struct sr_if* oif = sr_get_interface(sr, rt->interface);
    if (!oif){
      printf("interface not found\n");
      return;
    }

    send_packet(sr, packet, len, oif, rt->gw.s_addr);
  }

}

void sr_handlepacket(struct sr_instance* sr,
        uint8_t * packet/* lent */,
        unsigned int len,
        char* interface/* lent */)
{
  /* REQUIRES */
  assert(sr);
  assert(packet);
  assert(interface);

  printf("*** -> Received packet of length %d\n", len);

  if (len < sizeof(sr_ethernet_hdr_t)){
    printf("Error: Packet size smaller than ethernet header \n");
    return;
  }

  if (ethertype(packet) == ethertype_arp){
    printf("received arp packet\n");
    handle_arp_packet(sr, packet, len, interface);
  }
  else if (ethertype(packet) == ethertype_ip){
    handle_ip_packet(sr, packet, len, interface);
  }

}/* end sr_ForwardPacket */

